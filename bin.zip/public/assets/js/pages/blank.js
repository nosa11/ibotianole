var Page = {
    createBlank: function() {
        // Nothing to see here
    },
    init:function() {
        this.createBlank();
    }
}