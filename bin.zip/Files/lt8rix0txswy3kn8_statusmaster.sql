INSERT INTO lt8rix0txswy3kn8.statusmaster (StatusMasterId, Status) VALUES (1, 'pending');
INSERT INTO lt8rix0txswy3kn8.statusmaster (StatusMasterId, Status) VALUES (2, 'executed');
INSERT INTO lt8rix0txswy3kn8.statusmaster (StatusMasterId, Status) VALUES (3, 'transacted');
INSERT INTO lt8rix0txswy3kn8.statusmaster (StatusMasterId, Status) VALUES (4, 'on hold');