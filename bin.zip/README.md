# iBitcoin - Crypto
iBitcoin is a web app for trade bitcoin with market price. User can buy/sell bitcoin with real time price. iBitcoin provide virtual wallet system to handle all trades. Purpose of iBitcoin is to learn bitcoin trading to user without any real money transaction. At the time of registraion iBitcoin provide some virtual money in wallet for trading. This money is not real and it is used only on ibitcoin web app. All the price will be fetched from bitmex server with live data and currency rate will be refresh with 1hr interval.

### Credentials
    - UserName : ankitkanojia.rs@gmail.com  
    - Password : 12345
    
## iBitcoin APP
![](https://raw.githubusercontent.com/ankitkanojia/nodecrypto/master/public/images/iBitcoin.jpg)    
